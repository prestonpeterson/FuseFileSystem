#!/bin/sh
cd myfs
ls -la
cat first_file
cat second_file
cat third_file
cat fourth_file
cat fourth_file
cat fourth_file
touch fifth_file
