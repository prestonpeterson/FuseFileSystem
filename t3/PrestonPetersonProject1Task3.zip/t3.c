/**
* Name: Preston Peterson
* Lab/task: Project 1 Task 3
* Date: 11/13/16
**/

#include "t3.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


void init(NODE **memory, unsigned char **bitvector, int num_of_blocks) {
	printf("Initializing memory and superblock...\n");
	size_t bitvector_size = (num_of_blocks/8) * sizeof(char);
	*bitvector = malloc(bitvector_size);
	memset(*bitvector, 0x00, bitvector_size);

	*memory = malloc(num_of_blocks * sizeof(NODE));
	FS_NODE fd;
	strcpy(fd.name, "/");
	fd.creat_t = 0;
	fd.access_t = 0;
	fd.mod_t = 0;
	fd.access = 0;
	fd.owner = 0;
	fd.size = 0;
	fd.block_ref = 1;

	NODE superblock;
	superblock.type = DIR;
	superblock.content.fd = fd;
	*memory[0] = superblock;
	(*bitvector)[0] = (*bitvector)[0] | 0x80;

	(*memory)[1].type = INDEX;
	memset((*memory)[1].content.index, 0, INDEX_SIZE-1);
	(*bitvector)[0] = (*bitvector)[0] | 0x40;
	printf("Initialization complete\n");
}


int find_zero_bit(unsigned char bitvector[], int bitvector_len, int start_index, int *offset, int *mask) {
	int i;
	*mask = 0x80;
	*offset = 0;
	if (start_index >= bitvector_len)
		start_index = 0;
	for (i = start_index; i < bitvector_len; i++) {
		if ((int)bitvector[i] != 0xFF) {
			// printf("bitvector[%d] = %d\n", i, bitvector[i]);
			while (*mask != 0x00) {
				if ((bitvector[i] & *mask) == 0x00) {
					return i;
				}
				*mask = (*mask) / 2;
				(*offset)++;
			}
		}
	}
	return -1;
}

int convert_index_to_block_number(int bitvector_len, int bitvector_index, int index_offset) {
	int blockNumber = (8 * bitvector_index) + index_offset;
	if (blockNumber > (bitvector_len * 8))
		return -1; // blockNumber out of bounds
	else
		return blockNumber;
}

int convert_block_number_to_index(int bitvector_len, int blockNumber, int *mask) {
	int bitvector_index = blockNumber / 8;
	int bitvector_offset = blockNumber % 8;
	*mask = 0x80;
	int i;
	for (i = 0; i < bitvector_offset; i++) {
		*mask /= 2;
	}
	return bitvector_index;
}

int flip_bit(int byte, int mask) {
	return byte ^ mask;
}

int create_file(NODE *memory, unsigned char *bitvector, int bitvector_len, char *name, mode_t access) {
	int mask = 0x00;
	int offset = 0;
	int index = find_zero_bit(bitvector, bitvector_len, 0, &offset, &mask);
	int file_offset = offset;
	if (index == -1) {
		// can't create file. no available bits
		printf("Can't create file. No blocks available\n");
		return -1; 
	}
	bitvector[index] = flip_bit(bitvector[index], mask);
	int file_blockNumber = (8 * index) + offset;

	memory[file_blockNumber].type = FIL;
	strcpy(memory[file_blockNumber].content.fd.name, name);
	memory[file_blockNumber].content.fd.creat_t = time(NULL);
	memory[file_blockNumber].content.fd.access_t = time(NULL);
	memory[file_blockNumber].content.fd.mod_t = time(NULL);
	if (access <= 0) {
		// default access is 744 or rwxr--r--
		memory[file_blockNumber].content.fd.access = S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IROTH;
	}
	else {
		memory[file_blockNumber].content.fd.access = access;
	}
	memory[file_blockNumber].content.fd.size = 0;

	// find available block and create data node for the file
	mask = 0x00;
	int data_index = find_zero_bit(bitvector, bitvector_len, index, &offset, &mask);
	int data_blockNumber = convert_index_to_block_number(bitvector_len, data_index, offset);
	if (data_blockNumber == -1) {
		printf("CREATE_FILE FUNCTION. Error: data node block %d out of bounds.\n", data_blockNumber);
		return -1;
	}
	bitvector[data_index] = flip_bit(bitvector[data_index], mask);
	memory[data_blockNumber].type = DATA;

	// tell the file where its data node is
	memory[file_blockNumber].content.fd.block_ref = data_blockNumber;

	printf("Created file \"%s\" in block %d with data node in block %d. bitvector[%d] offset %d\n", 
		name, data_blockNumber, file_blockNumber, index, file_offset);
	return file_blockNumber;
}

int create_dir(NODE *memory, unsigned char *bitvector, int bitvector_len, char *name, mode_t access) {
	int mask = 0x00;
	int offset = 0;
	int index = find_zero_bit(bitvector, bitvector_len, 0, &offset, &mask);
	int dir_offset = offset;

	bitvector[index] = flip_bit(bitvector[index], mask);
	if (index == -1) {
		// can't create file. no available bits
		printf("Can't create file. No blocks available\n");
		return -1; 
	}
	
	int dir_blockNumber = convert_index_to_block_number(bitvector_len, index, offset);
	if (dir_blockNumber == -1) {
		printf("CREATE_DIR FUNCTION. Error: dir block %d out of bounds\n", dir_blockNumber);
		return -1;
	}

	memory[dir_blockNumber].type = DIR;
	strcpy(memory[dir_blockNumber].content.fd.name, name);
	memory[dir_blockNumber].content.fd.creat_t = time(NULL);
	memory[dir_blockNumber].content.fd.access_t = time(NULL);
	memory[dir_blockNumber].content.fd.mod_t = time(NULL);
	if (access <= 0) {
		// default access is 744 or rwxr--r--
		memory[dir_blockNumber].content.fd.access = S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IROTH;
	}
	else
		memory[dir_blockNumber].content.fd.access = access;
	memory[dir_blockNumber].content.fd.size = 0;

	// find available block and create index node for the directory
	mask = 0x00;
	int indexnode_index = find_zero_bit(bitvector, bitvector_len, index, &offset, &mask);
	int index_blockNumber = convert_index_to_block_number(bitvector_len, indexnode_index, offset);
	if (index_blockNumber == -1) {
		printf("CREATE_DIR FUNCTION. Error: index node block %d out of bounds.\n", index_blockNumber);
		return -1;
	}
	bitvector[indexnode_index] = flip_bit(bitvector[indexnode_index], mask);
	memory[index_blockNumber].type = INDEX;
	memset(memory[index_blockNumber].content.index, 0, INDEX_SIZE-1);

	// tell directory where its index node is
	memory[dir_blockNumber].content.fd.block_ref = index_blockNumber;
	printf("Created directory \"%s\" in block %d with index node in block %d. bitvector[%d] offset %d\n", 
		name, index_blockNumber, dir_blockNumber, index, dir_offset);
	return dir_blockNumber;
}

int delete_file(NODE *memory, unsigned char *bitvector, int bitvector_len, char *name, int blockNumber) {
	if ((blockNumber <= 1 && strlen(name) == 0) 
		|| (blockNumber >= (bitvector_len * 8))
		|| (memory[blockNumber].type == DIR)) 
	{
		printf("DELETE_FILE FUNCTION. invalid file name, type, or block number.\n");
		return -1;
	}
	int bitvector_index, bitvector_offset;
	if (blockNumber > 1) {
		// delete file by block number
		bitvector_index = blockNumber / 8;
		bitvector_offset = blockNumber % 8;
		int mask = 0x80;
		int i;
		for (i = 0; i < bitvector_offset; i++) {
			mask /= 2;
		}
		if ((bitvector[bitvector_index] & mask) != 0) {
			bitvector[bitvector_index] = flip_bit(bitvector[bitvector_index], mask);
		}
	}
	else {
		// delete file by name
		printf("TODO: delete file by name\n");
		bitvector_index = 0;
		bitvector_offset = 0;
	}
	
	if (memory[blockNumber].type == FIL) {
		// delete file's data node
		int data_blockNumber = memory[blockNumber].content.fd.block_ref;
		delete_file(memory, bitvector, bitvector_len, "", data_blockNumber);
		printf("Deleted file \"%s\" in block %d and bitvector[%d] offset %d, and file's data node in block %d\n", 
		memory[blockNumber].content.fd.name, blockNumber, bitvector_index, bitvector_offset, data_blockNumber);
	}
	
	return 0;
}

int delete_dir(NODE *memory, unsigned char *bitvector, int bitvector_len, char *name, int blockNumber) {
	if ((blockNumber <= 1 && strlen(name) == 0)
		|| (blockNumber >= (bitvector_len * 8))
		|| (memory[blockNumber].type != DIR)) 
	{
		printf("DELETE_DIR FUNCTION. invalid dir name, type, or block number.\n");
		return -1;
	}
	int bitvector_index, bitvector_offset;
	if (blockNumber > 1) {
		// delete dir by block number
		bitvector_index = blockNumber / 8;
		bitvector_offset = blockNumber % 8;
		int mask = 0x80;
		int i;
		for (i = 0; i < bitvector_offset; i++) {
			mask /= 2;
		}
		printf("mask = %d\n", mask);
		if ((bitvector[bitvector_index] & mask) != 0) {
			bitvector[bitvector_index] = flip_bit(bitvector[bitvector_index], mask);
		}
	}
	else {
		// delete file by name
		printf("TODO: delete dir by name\n");
		bitvector_index = 0;
		bitvector_offset = 0;
	}
	// kill all children of the dir
	int i;
	int index = memory[blockNumber].content.fd.block_ref;
	int val;
	for (i = 0; i < INDEX_SIZE; i++) {
		val = memory[index].content.index[i];
		if (val > 1) {;
			if (memory[val].type == FIL)
				delete_file(memory, bitvector, bitvector_len, "", val);
			else if (memory[val].type == DIR)
				delete_dir(memory, bitvector, bitvector_len, "", val);
		}
	}
	
	printf("Deleted directory \"%s\" in block %d and bitvector[%d] offset %d\n", 
		memory[blockNumber].content.fd.name, blockNumber, bitvector_index, bitvector_offset);
	
	return 0;
}

int obtain_file_information(NODE *memory, unsigned char *bitvector, int bitvector_len, char *name, int blockNumber) {
	if ((blockNumber <= 1 && strlen(name) == 0)
		|| (blockNumber >= (bitvector_len * 8))
		|| (memory[blockNumber].type != DIR && memory[blockNumber].type != FIL))
	{
		printf("OBTAIN_FILE_INFORMATION FUNCTION. invalid file name, type, or block number.\n");
		return -1;
	}
	printf("Obtaining file information for file or directory in block %d... ", blockNumber);
	// ensure file exists in bitvector
	int mask = 0x00;
	int bitvector_index = convert_block_number_to_index(bitvector_len, blockNumber, &mask);
	if (((bitvector[bitvector_index]) & mask) != mask) {
		printf("No file exists in block %d\n", blockNumber);
		return -1;
	}
	
	printf("\n%2s FILE INFORMATION:\n", "");
	printf("%2s %-25s ", "", "Type:");
	if (memory[blockNumber].type == DIR)
		printf("DIR\n");
	else
		printf("FILE\n");
	printf("%2s %-25s %-25s\n", "", "Name:", memory[blockNumber].content.fd.name);
	struct tm *create = localtime(&(memory[blockNumber].content.fd.creat_t));
    char s[64];
    strftime(s, sizeof(s), "%c", create);
    printf("%2s %-25s %-20s\n", "", "Create time:", s);
    struct tm *access = localtime(&(memory[blockNumber].content.fd.access_t));
    strftime(s, sizeof(s), "%c", access);
    printf("%2s %-25s %-20s\n", "", "Last access time:", s);
    struct tm *mod = localtime(&(memory[blockNumber].content.fd.mod_t));
    strftime(s, sizeof(s), "%c", mod);
    printf("%2s %-25s %-20s\n", "", "Last modification time:", s);
    printf("%2s %-25s %-20d\n", "", "Access rights:", memory[blockNumber].content.fd.access); 
    printf("%2s %-25s %-20d\n", "", "Owner:", memory[blockNumber].content.fd.owner);

	return 0;
}

int main(int argc, char *argv[]) {
	int num_of_blocks = 256; // 2^8
	unsigned char *bitvector;
	int bitvector_len = num_of_blocks / 8;
	NODE *memory;

	init(&memory, &bitvector, num_of_blocks);

	int file1 = create_file(memory, bitvector, bitvector_len, "file1", 0);
	int file2 = create_file(memory, bitvector, bitvector_len, "file2", 0);
	int file3 = create_file(memory, bitvector, bitvector_len, "file3", 0);

	int dir1 = create_dir(memory, bitvector, bitvector_len, "dir1", 0);
	int dir2 = create_dir(memory, bitvector, bitvector_len, "dir2", 0);
	int dir3 = create_dir(memory, bitvector, bitvector_len, "dir3", 0);
	int dir4 = create_dir(memory, bitvector, bitvector_len, "dir4", 0);
	int dir5 = create_dir(memory, bitvector, bitvector_len, "dir5", 0);
	int dir6 = create_dir(memory, bitvector, bitvector_len, "dir6", 0);

	obtain_file_information(memory, bitvector, bitvector_len, "", file1);
	delete_file(memory, bitvector, bitvector_len, "", file1);
	obtain_file_information(memory, bitvector, bitvector_len, "", file1);

	int file4 = create_file(memory, bitvector, bitvector_len, "file4", 0);
	int dir7 = create_dir(memory, bitvector, bitvector_len, "dir7", 0);
	obtain_file_information(memory, bitvector, bitvector_len, "", dir7);
	delete_dir(memory, bitvector, bitvector_len, "", dir7);
	obtain_file_information(memory, bitvector, bitvector_len, "", dir7);

	free(memory);
    return 0;
}